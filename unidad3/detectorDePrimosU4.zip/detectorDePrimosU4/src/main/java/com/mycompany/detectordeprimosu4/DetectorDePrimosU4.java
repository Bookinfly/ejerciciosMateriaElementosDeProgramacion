/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.detectordeprimosu4;

/**
 *
 * @author amado
 */
public class DetectorDePrimosU4 {

    public static void main(String[] args) {
        Window W = new Window();
        W.setVisible(true);
    }
}
