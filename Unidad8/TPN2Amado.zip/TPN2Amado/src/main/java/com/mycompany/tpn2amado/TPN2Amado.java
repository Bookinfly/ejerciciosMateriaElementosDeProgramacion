/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tpn2amado;

/**
 *
 * @author amado
 * 
 */
public class TPN2Amado {

    public static void main(String[] args) {
        System.out.println("app is running!");
        Window W = new Window();
        W.setVisible(true);
    }
    
  
}
