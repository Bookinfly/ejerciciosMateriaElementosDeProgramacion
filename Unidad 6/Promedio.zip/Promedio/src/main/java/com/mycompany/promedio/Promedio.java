/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.promedio;

/**
 *
 * @author amado
 */
public class Promedio {

    public static void main(String[] args) {
        Ventana V = new Ventana();
        V.setVisible(true);
    }
}
