/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package U7Entrega;

/**
 *
 * @author amado
 */
public class U7Entrega {

    public static void main(String[] args) {
        System.out.println("U7 Entrega run");
        Ventana V = new Ventana();
        V.setVisible(true);
    }
}
