/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio7_04;

/**
 *
 * @author Amado Nahuel
 */
public class Ejercicio7_04 {

    public static void main(String[] args) {
        System.out.println("Ejercicio7_04 run");
        PrismaTriangularForm PTF = new PrismaTriangularForm();
        PTF.setVisible(true);
        
        
    }
}
