/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio7_02;

/**
 *
 * @author Amado Nahuel
 */
public class Ejercicio7_02 {

    public static void main(String[] args) {
        System.out.println("Ejercicio7_02 run");
        PrismaTriangularForm PTF = new PrismaTriangularForm();
        PTF.setVisible(true);
        
        
    }
}
