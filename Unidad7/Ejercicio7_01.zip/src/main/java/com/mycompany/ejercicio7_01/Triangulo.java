/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio7_01;

/**
 *
 * @author Fotografia
 */
public class Triangulo {
    private double a; //lado a
    
    public Triangulo(double a){
        this.a = a;
    }
    
    public double calcularAltura() {
        return Math.sqrt(Math.pow(a, 2) - Math.pow(a / 2, 2));
    }
    
    public double calcularSuperficie() {
        double h = calcularAltura();
        return (a * h / 2);
        
    }
    
    public double getA() {
        return a;
    }
    
      public void setA(double a) {
        this.a = a;
    }
}
