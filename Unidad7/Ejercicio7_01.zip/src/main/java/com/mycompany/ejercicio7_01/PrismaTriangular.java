/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio7_01;

/**
 *
 * @author Fotografia
 * 
 * Triángulo (triangulo1): Representa una de las caras triangulares del prisma, con lado a.

Rectángulo (rectangulo): Representa una de las caras rectangulares del prisma, con lados a y b.

Método calcularSuperficie():
* Calcula la superficie total del prisma triangular sumando dos veces la superficie del triángulo
* y tres veces la superficie del rectángulo, lo cual es correcto según la especificación de tener
* 2 caras triangulares y 3 caras rectangulares.
 */
public class PrismaTriangular {
    private Triangulo triangulo1;
    private Rectangulo rectangulo;

    public PrismaTriangular(double a, double b) {
        this.triangulo1 = new Triangulo(a);
        this.rectangulo = new Rectangulo(a, b);
    }

    public double calcularSuperficie() {
        double supTriangulo = triangulo1.calcularSuperficie();
        double supRectangulo = rectangulo.calcularSuperficie();
        return 2 * supTriangulo + 3 * supRectangulo;
    }
}
