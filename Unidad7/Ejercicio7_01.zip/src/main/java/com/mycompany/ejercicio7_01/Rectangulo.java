/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio7_01;

/**
 *
 * @author Fotografia
 */
public class Rectangulo {
    private double a; // Base
    private double b; // Altura

    public Rectangulo(double a, double b) {
        this.a = a;
        this.b = b;
    }

    public double calcularSuperficie() {
        return a * b;
    }
    
    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }
}

