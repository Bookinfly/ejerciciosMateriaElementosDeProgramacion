/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio5_9;

/**
 *
 * @author amado
 */
public class Ejercicio5_9 {

    public static void main(String[] args) {
        System.out.println("app run");
        Ventana V = new Ventana();
        V.setVisible(true);
    }
}
